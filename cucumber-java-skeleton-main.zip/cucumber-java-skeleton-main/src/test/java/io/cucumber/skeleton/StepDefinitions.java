package io.cucumber.skeleton;

import io.cucumber.java.en.Given;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Action;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;

public class StepDefinitions {
	public static WebDriver driver;
	
	public void browserSetUp() {
	
	System.setProperty("webdriver.gecko.driver","C:\\jre\\JV-Work\\geckodriver-v0.29.1-win64\\geckodriver.exe" );
	driver = new FirefoxDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	@Given("I add four different product to my list$")
	public void I_add_four_different_product_to_my_list() throws Throwable {
		browserSetUp();
        driver.navigate().to("https://testscriptdemo.com");
        driver.findElement(By.id("cc-window")).click();
        driver.findElement(By.xpath("/html/body/div[1]/div[5]/a[1]")).click();
        
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)", "");
        
        driver.findElement(By.xpath("//a[@data-title='Add to wishlist' and @data-product-id='14']")).sendKeys(Keys.ENTER);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[@data-title='Add to wishlist' and @data-product-id='20']")).sendKeys(Keys.ENTER);

        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[@data-title='Add to wishlist' and @data-product-id='23']")).sendKeys(Keys.ENTER);

        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[@data-title='Add to wishlist' and @data-product-id='24']")).sendKeys(Keys.ENTER);

        Thread.sleep(1000);
        //driver.manage().timeouts().implicitlyWait(1000000, TimeUnit.SECONDS);
        
		}

	@When("I view my wish list table$")
	public void I_view_my_wish_list_table() throws Throwable {
		//WebElement element = driver.findElement(By.className("elementor-button-wrapper"));
		//browserSetUp();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("arguments[0].scrollIntoView();", element); 
        js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
		driver.findElement(By.xpath("//a[@title='Wishlist']")).click();
		Thread.sleep(1000);
		}

	@And("click search button$")
	public void click_search_button() throws Throwable {
		//browserSetUp();
		driver.findElement(By.xpath("/html/body/div[5]/div[2]/form/div[1]/div[1]/div[2]/button/div/span/svg")).click();
	}

	@Then("I find total four selected item in my wish list$")
	public void I_find_total_four_selected_item_in_my_wish_list() throws Throwable {
		List<WebElement> rows = driver.findElements(By.xpath("//table[@class='shop_table cart wishlist_table wishlist_view traditional responsive   ']/tbody/tr"));
		int count = rows.size();
		Assert.assertEquals(count, 4);
	}
	
    @When("I search for lowest price product")
    public void I_search_for_lowest_price_product() {
    	List<WebElement> rows = driver.findElements(By.xpath("//table[@class='shop_table cart wishlist_table wishlist_view traditional responsive   ']/tbody/tr/td[4]/span/bdi"));
    	for (int i = 0; i < rows.size(); i++) {
    	    String price = rows.get(i).getText();
    	    if (price.equalsIgnoreCase("£20.00"))
    		    	driver.findElement(By.xpath("//table[@class='shop_table cart wishlist_table wishlist_view traditional responsive   ']/tbody/tr/td[3]/a")).click();	
    	    break;
    		}
    }
    	
    @And("I am able to add or buy lowest price product to my cart")
    public void I_am_able_to_add_or_buy_lowest_price_product_to_my_cart() {
    	    	driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/article/div[2]/div[2]/form/button")).click();
   
    }
    
    @Then("I am able to verify the item in my cart$")
	public void I_am_able_to_verify_the_item_in_my_cart() throws Throwable {
    	String productWishToAdd=driver.findElement(By.xpath("//table[@class='shop_table cart wishlist_table wishlist_view traditional responsive   ']/tbody/tr[3]/td[3]/a")).getText();
    	driver.findElement(By.xpath("//table[@class='shop_table cart wishlist_table wishlist_view traditional responsive   ']/tbody/tr[3]/td[6]/a")).click();
    	driver.findElement(By.xpath("/html/body/div[2]/div[1]/div/div/div[3]/div[1]/div/div/a/i")).click();
    	String productAddedInCart=driver.findElement(By.xpath("/html/body/div[2]/div[3]/div/div/article/div/div/div[1]/div/form/table/tbody/tr[1]/td[3]/a")).getText();
    	Assert.assertTrue(productWishToAdd.equalsIgnoreCase(productAddedInCart));
    }
}

